require "test_helper"

class EstudianteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
